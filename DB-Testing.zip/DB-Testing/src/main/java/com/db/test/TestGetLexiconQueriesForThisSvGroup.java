package com.db.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.IteratorUtils;
import org.h2.util.StringUtils;
import org.junit.Test;

import com.db.connection.DBManager;
import com.db.util.SqlStmtQuery;
import com.db.util.Util;

public class TestGetLexiconQueriesForThisSvGroup extends TestCase {
	
	@Test
	public void testGetLexiconQueriesForThisSvGroup() throws SQLException, IOException {
		Connection conn = DBManager.getDBConnection();
		setUpDb("svgrouplexiconxref");
		setUpDb("svlexiconquery");
		PreparedStatement statement = conn.prepareStatement(SqlStmtQuery.GetLexiconQueriesForThisSvGroupStmt_1);
		statement.setString(1, "GRP_EMAIL_TEST#svg#0000000000000000000000001d555ff6fa00000162900c552f00000000");
		ResultSet rs = getResultsFromPreparedStmt(statement, conn);
		List<String> ids = new ArrayList<String>();
		while(rs.next()) {
			System.out.println(rs.getString(1));
			ids.add(rs.getString(1));
		}
		String query = String.format(SqlStmtQuery.GetLexiconQueriesForThisSvGroupStmt, Util.questionMarks(ids.size()));
		System.out.println(query);
		PreparedStatement statement2 = conn.prepareStatement(query);
		for (String string : ids) {
			statement2.setString(ids.indexOf(string)+1, string);
		}
		rs = statement2.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getString(4));
		}
	}
	
}
