package com.db.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import com.db.connection.DBManager;
import com.db.util.SqlStmtQuery;

public class TestUpdateLexiconBlob extends TestCase {
	
	@Test
	public void testUpdateLexiconBlob() throws IOException, SQLException {
		setUpDb("svlexiconquery");
		Connection connection = DBManager.getDBConnection();
		//String selectQuery = String.format(SqlStmtQuery.UpdateLexiconBlobStmt, "'L0000001'", 0);
		PreparedStatement stmt = connection.prepareStatement(SqlStmtQuery.UpdateLexiconBlobStmt);
		stmt.setString(1, "L0000002");
		boolean x = stmt.execute();
		System.out.println(x);
		String sql = "select * from svlexiconquery";
		stmt = connection.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getString(1));
		}
		
	}

}
