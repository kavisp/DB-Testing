package com.db.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import com.db.connection.DBManager;
import com.db.util.SqlStmtQuery;

public class TestGetMappedLexicons extends TestCase {
	
	@Test
	public void testGetMappedLexicons() throws IOException, SQLException {
		Connection conn = DBManager.getDBConnection();
		setUpDb("svgrouplexiconxref");
		PreparedStatement statement = conn.prepareStatement(SqlStmtQuery.GetMappedLexicons);
		statement.setString(1, "GRP_EMAIL_TEST#svg#0000000000000000000000001d555ff6fa00000162900c552f00000000");
		
		ResultSet set = statement.executeQuery();
		while(set.next()) {
			System.out.println(set.getString(1));
		}
	}

}
