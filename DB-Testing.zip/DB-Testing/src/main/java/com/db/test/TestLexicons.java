package com.db.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import com.db.connection.DBManager;
import com.db.util.SqlStmtQuery;

public class TestLexicons extends TestCase {
	
	@Test
	public void testLexicons() throws IOException, SQLException {
		Connection conn = DBManager.getDBConnection();
		setUpDb("svlexiconquery");
		PreparedStatement statement = conn.prepareStatement(SqlStmtQuery.GetLexiconStmt);
		statement.setString(1, "testdomain1");
		ResultSet set = statement.executeQuery();
		while(set.next()) {
			System.out.println(set.getString(1));
		}
	}

}
