package com.db.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.db.connection.DBManager;
import com.ibatis.common.jdbc.ScriptRunner;

public class TestCase {

	public ResultSet getResultsFromSqlString(String sql, Connection conn) throws SQLException {
		return conn.prepareStatement(sql).executeQuery();
	}

	public ResultSet getResultsFromPreparedStmt(PreparedStatement statement, Connection conn) throws SQLException {
		return statement.executeQuery();
	}

	public void setUpDb(String dbName) throws IOException, SQLException {
		Connection connection = DBManager.getDBConnection();
		ScriptRunner sr = new ScriptRunner(connection, false, false);
		// Give the input file to Reader
		Reader reader = new BufferedReader(
				new FileReader(this.getClass().getResource("/" + dbName + ".sql").getFile()));
		// Execute script
		sr.runScript(reader);
	}
}
