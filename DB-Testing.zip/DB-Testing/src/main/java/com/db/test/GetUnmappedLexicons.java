package com.db.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.db.connection.DBManager;
import com.db.util.SqlStmtQuery;
import com.db.util.Util;

public class GetUnmappedLexicons extends TestCase {
	
	@Test
	public void testGetUnmappedLexicons() throws IOException, SQLException {
		Connection connection = DBManager.getDBConnection();
		setUpDb("svgrouplexiconxref");
		setUpDb("svlexiconquery");
		List<String> ids = new ArrayList<String>();
		PreparedStatement statement = connection.prepareStatement(SqlStmtQuery.GetUnMappedLexicons);
		statement.setString(1, "GRP_EMAIL_TEST#svg#0000000000000000000000001d555ff6fa00000162900c552f00000000");
		ResultSet rs = statement.executeQuery();
		while(rs.next()) {
			ids.add(rs.getString(1));
		}
		String query = String.format(SqlStmtQuery.GetUnMappedLexicons_1, Util.questionMarks(ids.size()));
		int i = 0;
		statement = connection.prepareStatement(query);
		statement.setString(++i, "testdomain1");
		for(String id: ids) {
			statement.setString(++i, "L0000001");
		}
		rs = statement.executeQuery();
		while(rs.next()) {
			System.out.println("result " +rs.getString(1));
		}
		System.out.println("out");
	}

}
