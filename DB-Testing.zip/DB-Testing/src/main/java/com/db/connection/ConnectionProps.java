package com.db.connection;

public interface ConnectionProps {
	String DB_DRIVER = "org.h2.Driver";
	String DB_CONNECTION = "jdbc:h2:mem:test;DB_CLOSE_DELAY=-1";
	String DB_USER = "sa";
	String DB_PASSWORD = "h2db@123";
	String TCP_PORT = "8082";
}
