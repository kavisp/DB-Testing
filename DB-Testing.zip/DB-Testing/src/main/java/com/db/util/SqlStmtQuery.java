package com.db.util;

public class SqlStmtQuery {
	public static final String GetLexiconQueriesForThisSvGroupStmt = "SELECT * FROM SvLexiconQuery WHERE INACTIVE = 0 and notSnapShot = 1 and SvLexiconId in (%s)";
	public static final String GetLexiconQueriesForThisSvGroupStmt_1 = "SELECT SvLexiconId FROM SvGroupLexiconXRef WHERE SvGroupId = ?";
	public static final String GetLexiconStmt = "SELECT SvLexiconId FROM SvLexiconQuery WHERE notSnapShot = 1 and DomainID = ? order by svlexiconname";
	public static final String GetMappedLexicons = "SELECT SvLexiconID from SvGroupLexiconXRef where SvGroupID =?";
	public static final String GetUnMappedLexicons = "select SvLexiconId from SvGroupLexiconXRef where SvGroupID =?";
	public static final String GetUnMappedLexicons_1 = "SELECT SvLexiconId from SvLexiconQuery where (notSnapShot = 1) and InActive = 0 and (DomainID = ?) and SvLexiconId not in ( %s ) order by svlexiconname";
	public static final String UpdateLexiconBlobStmt = "insert into SvLexiconQuery (SvLexiconId, SvLexiconName, SvLexiconBlobVer, SvLexiconBlob, inactive, DomainID, CreatedBy, DateCreated, lastModifiedDate)"
			+ " select  'L0000002', SvLexiconName, SvLexiconBlobVer, SvLexiconBlob, 0, DomainID, CreatedBy, DateCreated, current_timestamp from SvLexiconQuery where SvLexiconId = ?";
	
}
