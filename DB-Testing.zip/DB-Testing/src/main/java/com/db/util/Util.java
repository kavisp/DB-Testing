package com.db.util;

import org.apache.commons.collections.IteratorUtils;

public class Util {
	public static String questionMarks(int number) {
        // Note, this will become much simpler when we upgrade Apache Commons.
        return org.apache.commons.lang3.StringUtils.join(
                IteratorUtils.arrayIterator(org.apache.commons.lang3.StringUtils.repeat("?", number).toCharArray()),
                ","
        );
    }

}
