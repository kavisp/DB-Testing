package com.db.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StatementWrapper {
	
	public static PreparedStatement getStatement(Connection conn, String sql) throws SQLException {
		return conn.prepareStatement(sql);
	}

}
