package com.db.util;

public class SqlQuery {

	public static final String GetLexiconQueriesForThisSvGroup = "SELECT * FROM SvLexiconQuery WHERE INACTIVE = 0 and notSnapShot = 1 and SvLexiconId in "
			+ "(SELECT SvLexiconId FROM SvGroupLexiconXRef WHERE SvGroupId = 'GRP_EMAIL_TEST#svg#0000000000000000000000001d555ff6fa00000162900c552f00000000')";

	public static final String GetLexicons = "SELECT SvLexiconId FROM SvLexiconQuery WHERE notSnapShot = 1 and DomainID = '' order by svlexiconname";
}
