CREATE TABLE svlexiconquery (
    svlexiconid character(8) NOT NULL,
    svlexiconname character varying(40) NOT NULL,
    svlexiconblobver character varying(6) NOT NULL,
    svlexiconblob text,
    inactive integer DEFAULT 0 NOT NULL,
    notsnapshot smallint DEFAULT 1 NOT NULL,
    domainid character varying(40) NOT NULL,
    createdby character varying(8),
    datecreated timestamp without time zone,
    lastmodifiedby character varying(8) DEFAULT 'U0000000'::character varying NOT NULL,
    lastmodifieddate timestamp without time zone NOT NULL
);

INSERT INTO svlexiconquery (svlexiconid, svlexiconname, svlexiconblobver, svlexiconblob, inactive, notsnapshot, domainid, createdby, datecreated, lastmodifiedby, lastmodifieddate) VALUES ('L0000001', 'test', '1.0', '', 0, 1, 'testdomain1', 'U0000003', '2018-04-04 08:12:15.276', 'U0000000', '2018-04-04 08:12:15.276');
INSERT INTO svlexiconquery (svlexiconid, svlexiconname, svlexiconblobver, svlexiconblob, inactive, notsnapshot, domainid, createdby, datecreated, lastmodifiedby, lastmodifieddate) VALUES ('L0000002', 'sample_lexicon', '1.0', 'hello', 0, 1, 'testdomain1', 'U0000003', '2018-04-04 09:43:21.007', 'U0000000', '2018-04-04 09:43:21.007');
