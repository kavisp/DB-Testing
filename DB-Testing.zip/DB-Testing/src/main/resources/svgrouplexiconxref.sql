CREATE TABLE svgrouplexiconxref (
    svgroupid character varying(105) NOT NULL,
    svlexiconid character(8) NOT NULL,
    lastmodifiedby character varying(8) DEFAULT 'U0000000'::character varying NOT NULL
);
INSERT INTO svgrouplexiconxref (svgroupid, svlexiconid, lastmodifiedby) VALUES ('newgrp#svg#0000000000000000000000001d555ff6fa000001628fb9048b00000000', 'L0000001', 'U0000000');
INSERT INTO svgrouplexiconxref (svgroupid, svlexiconid, lastmodifiedby) VALUES ('GRP_EMAIL_TEST#svg#0000000000000000000000001d555ff6fa00000162900c552f00000000', 'L0000001', 'U0000000');
INSERT INTO svgrouplexiconxref (svgroupid, svlexiconid, lastmodifiedby) VALUES ('GRP_EMAIL_TEST#svg#0000000000000000000000001d555ff6fa00000162900c552f00000000', 'L0000002', 'U0000000');

